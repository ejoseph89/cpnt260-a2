# CPNT260
## ASSIGNMENT 2: TEAM CARD 
## EMIL JOSEPH

Majority of this assignment was straight forward. The most challening part of it was adding and styling the images according to the specification.  

I used two images as flex items by making the card a flex container.  

I tried to set a '%' height for the images, but that did not seem to work.  

After playing with about four different copies of this assignment, I learned a lot more about making layouts with flexbox, and keeping text from breaking out of a container. But adding and styling images still remains a challenge.   

Watched a few minutes of this video: https://www.youtube.com/watch?v=GWE9ay9H7uU to get some ideas. 



